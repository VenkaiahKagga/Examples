import React from 'react';

function Loading() {
  return(
    <div id="loading">
      <div className="loader">Loading...</div>
    </div>
  );
}

export default Loading;