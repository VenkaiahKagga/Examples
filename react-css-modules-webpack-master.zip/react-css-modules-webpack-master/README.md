# React + CSS Modules + Webpack

## Getting Started

- `git clone` this repository
- `npm install`
- `node dev-server.js`
- `open http://localhost:3000`

## Bundling

```
npm run build-prod
```
