// import { Map } from 'immutable';
// import { fromJS } from 'immutable';

// const state = {
//   cats: [],
//   hobbies: []
// };

// export default fromJS(state)

export default {
  cats: [],
  hobbies: []
}