export default [
    { id: 'compulsive', name: 'resources.segments.data.compulsive' },
    { id: 'collector', name: 'resources.segments.data.collector' },
    { id: 'ordered_once', name: 'resources.segments.data.ordered_once' },
    { id: 'regular', name: 'resources.segments.data.regular' },
    { id: 'returns', name: 'resources.segments.data.returns' },
    { id: 'reviewer', name: 'resources.segments.data.reviewer' },
];
