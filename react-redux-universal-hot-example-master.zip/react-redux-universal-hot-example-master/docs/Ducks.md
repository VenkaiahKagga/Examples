This document has found [another, hopefully permanent, home](https://github.com/erikras/ducks-modular-redux).

Quack.
