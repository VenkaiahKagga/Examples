import React from 'react';

class AboutPage extends React.Component {
  render() {
    return (
      <div>
        <h1>About</h1>
        <p>coming soon!</p>
      </div>
    );
  }
}

export default AboutPage;