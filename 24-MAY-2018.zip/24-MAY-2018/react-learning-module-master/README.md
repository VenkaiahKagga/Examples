# react-learning-module

This module aims to provide a solid knowledge base for everyone trying to learn React, by walking you, the curious developer, through the making of a small, simplified, yet non-trivial e-commerce application.

The repo has separate branches for each step of the tutorial, in case you're too lazy to write or copy-paste the code (although I **strongly** recommend doing that) or just want to double-check stuff, or whatever.

For the tutorial, please go to: http://tszekely.github.io/react-learning-module/.
