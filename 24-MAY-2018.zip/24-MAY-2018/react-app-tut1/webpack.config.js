const webpack = require('webpack');
var config = {
    entry: ['react-hot-loader/patch','./main.js'],
    resolve:{
        extensions: ['*', '.js', '.jsx']
    },
    output: {
       path:__dirname+'/',
       publicPath:'/',
       filename: 'index.js'
    },
    plugins:[new webpack.HotModuleReplacementPlugin()],
    devServer: {
       hot: true,
       port: 8089,
       contentBase:'/',
    },
    module: {
        rules:[{
            test: /\.(js|jsx)$/,
            exclude: /node_modules/,
            use: ['babel-loader']
        }
        ]
    //    loaders: [
    //       {
    //          test: /\.jsx?$/,
    //          exclude: /node_modules/,
    //          loader: 'babel-loader',
    //          query: {
    //             presets: ['es2015', 'react']
    //          }
    //       }
    //    ]
    }
 }
 module.exports = config;