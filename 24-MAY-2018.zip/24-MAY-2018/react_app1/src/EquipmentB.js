import React, { Component } from "react";
 
class EquipmentB extends Component {
  render() {
    return (
      <div>
        <h2>Device Name>Equipment B</h2><br/>
        <label id="EquipmentB" name="EquipmentB" align="right">Equipment Name</label><br/>
        <input type="text" name="EquipmentName" id="EquipmentB" value="Equipment B" disable="true"/><br/>
        <label id="Vendor" label="Vendor">Vendor</label><br/>
        <input type="text" name="Vendor" id="Vendor"/><br/>
        <label id="Location" name="Location">Location</label><br/>
        <input type="text" name="Location" id="Location" width="70px"/><br/>
         <label id="Model" name="Model">Model</label><br/>
        <input type="text" name="Model" id="Model" width="70px"/><br/>
         <label id="Serial#" name="Serial#">Serial#</label><br/>
        <input type="text" name="Serial" id="Serial"  width="70px"/><br/>
         <label id="Description" name="Description">Description</label><br/>
        <input type="text" name="Description" id="Description" width="70px"/><br/>
      </div>
    );
  }
}
 
export default EquipmentB;