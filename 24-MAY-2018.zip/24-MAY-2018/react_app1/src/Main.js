import React, { Component } from "react";
import {
  Route,
  NavLink,
  HashRouter
} from "react-router-dom";
import Home from "./Home";
import DeviceName from "./DeviceName";
import Contact from "./Contact";
import EquipmentA from "./EquipmentA";
import EquipmentB from "./EquipmentB";
import EquipmentC from "./EquipmentC";
 
class Main extends Component {
  render() {
    return (
        <HashRouter>
        <div >
          <h1>Simple SPA</h1>
          <ul className="header">
            
            <li><NavLink to="/devicename">Device Name</NavLink><Submenu/></li>
          </ul>
          <div className="content">
            <Route path="/devicename" component={DeviceName}></Route>
            <Route path="/devicename" component={Submenu}></Route>
          </div>
             
        </div>
        </HashRouter>
        
    );
  }
}
 class Submenu extends React.Component {
  render() {
    return (
 <div>
          <ul>
            <li><NavLink to="/equipment-a">Equipment A</NavLink></li><br/>
            <li><NavLink to="/equipment-b">Equipment B</NavLink></li><br/>
            <li><NavLink to="/equipment-c">Equipment C</NavLink></li>
          </ul>
         <div className="content">
            <Route path="/equipment-a" component={EquipmentA}/>
            <Route path="/equipment-b" component={EquipmentB}/>
            <Route path="/equipment-c" component={EquipmentC}/>
          </div>
         </div>
    )
  }
}
export default Main;