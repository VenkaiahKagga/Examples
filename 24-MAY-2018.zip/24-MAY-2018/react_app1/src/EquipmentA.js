import React, { Component } from "react";
 
class EquipmentA extends Component {
  render() {
    return (
      <div >
        <h2>Device Name>Equipment A</h2><br/>
        <label id="EquipmentA" name="EquipmentA" align="right">Equipment Name</label><br/>
        <input type="text" name="EquipmentName" id="EquipmentA" value="Equipment A" disable="true"/><br/>
        <label id="Vendor" label="Vendor">Vendor</label><br/>
        <input type="text" name="Vendor" id="Vendor"/><br/>
        <label id="Location" name="Location">Location</label><br/>
        <input type="text" name="Location" id="Location" width="70px"/><br/>
         <label id="Model" name="Model">Model</label><br/>
        <input type="text" name="Model" id="Model" width="70px"/><br/>
         <label id="Serial#" name="Serial#">Serial#</label><br/>
        <input type="text" name="Serial" id="Serial" width="70px"/><br/>
         <label id="Description" name="Description">Description</label><br/>
        <input type="text" name="Description" id="Description" width="70px"/><br/>
      </div>
    );
  }
}
 
export default EquipmentA;