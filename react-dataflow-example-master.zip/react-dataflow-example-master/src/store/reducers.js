import topics from './topics/reducer';
import posts from './posts/reducer';

export {
  topics,
  posts
};
