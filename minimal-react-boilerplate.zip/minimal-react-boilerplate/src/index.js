import React from 'react';
import ReactDOM from 'react-dom';
import App from './App.js'
//import './app.scss';
//import styles from './style.css';

const title='My Minimal React Webpack Babel Setup Sample';
console.log('My Minimal React Webpack Babel Setup');
console.log('My Minimal React Webpack Babel Setup');

//ReactDOM.render(<div>{title}</div>, document.getElementById('app'));
ReactDOM.render(<App />, document.getElementById('app'));

module.hot.accept();