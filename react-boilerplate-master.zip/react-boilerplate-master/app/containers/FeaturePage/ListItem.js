import styled from 'styled-components';

const ListItem = styled.li`
  margin: 1em 0;
`;

export default ListItem;
